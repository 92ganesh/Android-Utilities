package com.example.student.fragments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements list.ItemSelected {
    TextView textView;
    ArrayList<String> description;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        description = new ArrayList<String>();
        description.add("description Item1");
        description.add("description Item2");
        description.add("description Item3");
        description.add("description Item4");
    }


    @Override
    public void onItemSelected(int index) {
        
    }
}
