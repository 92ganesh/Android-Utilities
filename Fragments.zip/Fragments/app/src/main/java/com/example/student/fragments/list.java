package com.example.student.fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */

public class list extends android.support.v4.app.ListFragment {
    ItemSelected activity;
    public interface  ItemSelected{
        void onItemSelected(int index);
    }
    public list() {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity=(ItemSelected)context;
     }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ArrayList<String> data = new ArrayList<String>();
        data.add("1. Item1");
        data.add("2. Item2");
        data.add("3. Item3");
        data.add("4. Item4");
        setListAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,data));
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        activity.onItemSelected(0);
    }

}

