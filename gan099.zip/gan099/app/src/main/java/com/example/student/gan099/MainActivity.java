package com.example.student.gan099;

import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private EditText toToastText;
    private Button clearButton;
    private Button toastButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toToastText = (EditText)findViewById(R.id.editText);
        clearButton = (Button)findViewById(R.id.clear);
        toastButton = (Button)findViewById(R.id.toast);

    }
}
