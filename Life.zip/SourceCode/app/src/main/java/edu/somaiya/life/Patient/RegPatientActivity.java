package edu.somaiya.life.Patient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.support.annotation.NonNull;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

import edu.somaiya.life.Doctor.Main2Activity;
import edu.somaiya.life.Doctor.RegistrationActivity;
import edu.somaiya.life.R;

public class RegPatientActivity extends AppCompatActivity {
    Button button1;
    private EditText e,p;
    String s,s1;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_patient);
        button1 = (Button)findViewById(R.id.rsp);
        e= (EditText)findViewById(R.id.pemailp);
        p= (EditText)findViewById(R.id.ppd);
        mAuth = FirebaseAuth.getInstance();
        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                s = e.getText().toString();
                s1 = p.getText().toString();
                if(s.length()==0){
                    Toast.makeText(RegPatientActivity.this, "Enter email address", Toast.LENGTH_LONG).show();
                }
                else if(s1.length()==0){
                    Toast.makeText(RegPatientActivity.this, "Enter password", Toast.LENGTH_LONG).show();
                }
                else {
                    //Global.uname = s;
                    mAuth.createUserWithEmailAndPassword(s,s1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                finish();
                                startActivity(new Intent(RegPatientActivity.this, MainActivity.class));

                                //Toast.makeText(getApplicationContext(), "User registered successfully", Toast.LENGTH_SHORT).show();

                            }
                /*else
                    Toast.makeText(getApplicationContext(), "Some Error Occured", Toast.LENGTH_SHORT).show();*/
                            else {

                                if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                    Toast.makeText(getApplicationContext(), "You are already registered", Toast.LENGTH_SHORT).show();

                                } else {
                                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }

                            }
                        }
                    });

                }
            }
        });
    }
}
