package edu.somaiya.life.Patient;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import edu.somaiya.life.Patient.Global;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import edu.somaiya.life.Doctor.LoginDActivity;
import edu.somaiya.life.Doctor.Main2Activity;
import edu.somaiya.life.R;

public class LoginPActivity extends AppCompatActivity {

    private Button sp;
    private Button b1;
    String s,s1;
    FirebaseAuth mAuth;
    private EditText e,p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_p);

        sp = (Button) findViewById(R.id.sp);
        b1=(Button) findViewById(R.id.regp);
        e= (EditText)findViewById(R.id.emailp);
        p= (EditText)findViewById(R.id.pp);

        sp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s = e.getText().toString();
                s1 = p.getText().toString();
                if(s.length()==0){
                    Toast.makeText(LoginPActivity.this, "Enter email address", Toast.LENGTH_LONG).show();
                }
                else if(s1.length()==0){
                    Toast.makeText(LoginPActivity.this, "Enter password", Toast.LENGTH_LONG).show();
                }
                else {
                    //Global.uname = s;
                    mAuth = FirebaseAuth.getInstance();

                    mAuth.signInWithEmailAndPassword(s,s1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(i);
                            } else {
                                Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(getApplicationContext(),RegPatientActivity.class);
                startActivity(i1);
            }
        });
    }
}
