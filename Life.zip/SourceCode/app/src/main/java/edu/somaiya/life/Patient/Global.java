package edu.somaiya.life.Patient;

import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import edu.somaiya.life.R;


/**
 * Created by Patra's Home on 02-10-2018.
 */

public class Global {
    public static int found, LargestPatientId;
    public static String currentUser,prescription,nextDate,nextTime;
    public static ArrayList<String> dateList=new ArrayList<>();
    public static ArrayList<String> presList=new ArrayList<>();
    public static ArrayList<String> nameAndPres=new ArrayList<>();
    public static DatabaseReference mDatabase;
    public static String uname="";

    public static void setUp(){
        currentUser="Balaji";

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("LargestPatientId").setValue("0");
        myRef.child("LargestPatientId").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LargestPatientId = Integer.parseInt((String)dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        Map<String,Object> presList = new HashMap<>();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        LargestPatientId++;
        Map<String,Object> history = new HashMap<>();
        history.put("05-05-2012","Amoxicillin"); history.put("14-06-2015","saridon"); history.put("17-06-2017","cough syrup"); history.put("20-08-2018","patanjali tablets");
        String patientName="Balaji"; String patientPres="patanjali tablets";
        presList.put(patientName,patientPres);
        PatientClass p = new PatientClass(patientName,patientPres,history);
        p.nextDate="25-12-2018"; p.nextTime="15:00";
        mDatabase.child("PatientClass").child(Integer.toString(LargestPatientId)).setValue(p);
        myRef.child("LargestPatientId").setValue(Integer.toString(LargestPatientId));

        LargestPatientId++;
        history = new HashMap<>();
        history.put("15-05-2014","Ativan"); history.put("14-06-2015","Alprazolam"); history.put("17-06-2017","cough syrup"); history.put("20-08-2018","Alprazolam");
        patientName="Sharma"; patientPres="TiRex";
        presList.put(patientName,patientPres);
        p = new PatientClass(patientName,patientPres,history);
        p.nextDate="16-11-2018"; p.nextTime="18:30";
        mDatabase.child("PatientClass").child(Integer.toString(LargestPatientId)).setValue(p);
        myRef.child("LargestPatientId").setValue(Integer.toString(LargestPatientId));



        Global.found=0;
        myRef.child("PatientClass").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> listOfUserId = dataSnapshot.getChildren();
                DataSnapshot currentDataSnapshot=null;
                for (DataSnapshot id : listOfUserId) {
                    if(id.child("name").getValue().equals(Global.currentUser)) {
                        Global.found=1;
                        Global.prescription = (String)id.child("prescription").getValue();
                        Global.nextDate = (String)id.child("nextDate").getValue();
                        Global.nextTime = (String)id.child("nextTime").getValue();
                        currentDataSnapshot = id;
                        break;
                    }
                }

                if(Global.found==1) {
                    Iterable<DataSnapshot> historyList = currentDataSnapshot.child("history").getChildren();
                    for (DataSnapshot history : historyList) {
                        Global.dateList.add(history.getKey());
                        Global.presList.add((String) history.getValue());
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });


    }
}


@IgnoreExtraProperties
class DoctorClass
{   public String name;
    public Map<String,Object> PatientPrescription;

    public DoctorClass() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public DoctorClass(String name, Map<String,Object> PatientPrescription) {
        this.name = name;
        this.PatientPrescription = PatientPrescription;
    }

}

@IgnoreExtraProperties
class PatientClass
{   public String name;
    public String prescription;
    public Map<String,Object> history;
    public String nextDate,nextTime;

    public PatientClass() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public PatientClass(String name, String prescription, Map<String,Object> history) {
        this.name = name;
        this.prescription = prescription;
        this.history = history;
        nextDate="";
        nextTime="";
    }
}


