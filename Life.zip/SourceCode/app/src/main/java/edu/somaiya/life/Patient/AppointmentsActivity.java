package edu.somaiya.life.Patient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import edu.somaiya.life.R;

public class AppointmentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);

        TextView ed = (TextView)findViewById(R.id.appointmentTime);
        ed.setText("Your next appointment is on "+Global.nextDate+" at "+Global.nextTime);
    }
}
