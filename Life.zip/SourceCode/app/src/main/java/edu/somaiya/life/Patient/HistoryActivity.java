package edu.somaiya.life.Patient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import edu.somaiya.life.R;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        if(Global.found==1) {
            addToActivity();
        }

    }

    public void addToActivity() {

        LinearLayout dateAct = (LinearLayout)findViewById(R.id.date);
        LinearLayout presAct = (LinearLayout)findViewById(R.id.pres);

        for(int i=0;i<Global.dateList.size();i++){
            /* Global.dateList and Global.presList are arraylists having dates need to be displayed on left and
               prescription list on right in activity_history.xml
            */

            TextView dateText = new TextView(this);
            dateText.setText(Global.dateList.get(i));
            dateAct.addView(dateText);

            TextView presText = new TextView(this);
            presText.setText(Global.presList.get(i));
            presAct.addView(presText);
        }

    }

}
