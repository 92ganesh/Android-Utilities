package edu.somaiya.life.Doctor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.somaiya.life.Patient.Global;
import edu.somaiya.life.R;

import android.support.annotation.NonNull;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class RegistrationActivity extends AppCompatActivity {

    private Button button;
    private EditText e,p;
    String s,s1;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        button = (Button)findViewById(R.id.rsd);
        e= (EditText)findViewById(R.id.remaild);
        p= (EditText)findViewById(R.id.rpd);
        mAuth = FirebaseAuth.getInstance();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s = e.getText().toString();
                s1 = p.getText().toString();
                if(s.length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter email address", Toast.LENGTH_LONG).show();
                }
                else if(s1.length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter password", Toast.LENGTH_LONG).show();
                }
                else {
                    //Global.uname = s;
                    mAuth.createUserWithEmailAndPassword(s,s1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                finish();
                                startActivity(new Intent(RegistrationActivity.this, Main2Activity.class));

                                //Toast.makeText(getApplicationContext(), "User registered successfully", Toast.LENGTH_SHORT).show();

                            }
                /*else
                    Toast.makeText(getApplicationContext(), "Some Error Occured", Toast.LENGTH_SHORT).show();*/
                            else {

                                if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                    Toast.makeText(getApplicationContext(), "You are already registered", Toast.LENGTH_SHORT).show();

                                } else {
                                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }

                            }
                        }
                    });

                }
            }
        });

    }
}
