package com.example.student.implicitintent;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button Dialer,Friend,Map,Facebook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Dialer = (Button)findViewById(R.id.Dialer);
        Friend = (Button)findViewById(R.id.Friend);
        Map = (Button)findViewById(R.id.Map);
        Facebook = (Button)findViewById(R.id.Facebook);

        Dialer.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(Intent.ACTION_DIAL);
                        startActivity(i);
                    }
                }

        );

        Friend.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9619758762"));
                        startActivity(i);
                    }
                }

        );

        Map.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse("geo:19.81,84.59") );
                        startActivity(i);
                    }
                }

        );

        Facebook.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String url ="https://www.facebook.com";
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                    }
                }

        );
    }



}
