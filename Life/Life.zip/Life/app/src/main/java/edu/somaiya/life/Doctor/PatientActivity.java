package edu.somaiya.life.Doctor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import edu.somaiya.life.Patient.Global;
import edu.somaiya.life.R;

public class PatientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient);



        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("PatientClass").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Global.nameAndPres = new ArrayList<>();
                Global.nameAndPres.add("Name\t\t\tPrescription");
                Iterable<DataSnapshot> listOfUserId = dataSnapshot.getChildren();
                for (DataSnapshot id : listOfUserId) {
                    String name = (String)id.child("name").getValue();
                    String pres = (String)id.child("prescription").getValue();
                    Global.nameAndPres.add(name+"\t\t\t"+pres);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Global.nameAndPres);
        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(itemsAdapter);
        Log.e("sdf ",Integer.toString(Global.nameAndPres.size()));
    }
}
