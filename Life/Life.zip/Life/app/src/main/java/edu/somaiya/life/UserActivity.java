package edu.somaiya.life;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import edu.somaiya.life.Doctor.LoginDActivity;
import edu.somaiya.life.Patient.Global;
import edu.somaiya.life.Patient.LoginPActivity;

public class UserActivity extends AppCompatActivity {
    private Button u1;
    private Button d1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        u1 = (Button) findViewById(R.id.button1);
        d1 = (Button) findViewById(R.id.button2);

        u1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), LoginDActivity.class);
                startActivity(i);
            }
        });

        d1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), LoginPActivity.class);
                startActivity(i);
            }
        });

        Global.setUp();
/*

        myRef.child("LargestDoctorId").setValue("0");
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LargestDoctorId = Integer.parseInt((String)dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        LargestDoctorId++;
        DoctorClass d = new DoctorClass("John",presList);
        myRef.child("DoctorClass").child(Integer.toString(LargestDoctorId)).setValue(d);
        myRef.child("LargestDoctorId").setValue(Integer.toString(LargestDoctorId));

        */
    }

}

